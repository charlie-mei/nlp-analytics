from flask import Flask, render_template
app = Flask("MyApp")

@app.route('/')
def hello_world():
    output = "WEATHER IS NICE"
    return render_template('index.html', result="WEATHER IS NICE")
    #return output

if __name__ == '__main__':
 app.run(host='localhost', port=5003)
